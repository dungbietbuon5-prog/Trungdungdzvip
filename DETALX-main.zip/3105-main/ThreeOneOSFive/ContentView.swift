// language: Swift, file: ContentView.swift
import SwiftUI
import UIKit

struct PatchFeature: Identifiable {
    let id = UUID()
    let name: String
    let desc: String
    let icon: String
    let color: Color
    let patchFileName: String
    var isOn: Bool = false
}

struct ContentView: View {
    @State private var selectedTab = 0
    @State private var showAlert = false
    @State private var alertMessage = ""
    
    // CẤU HÌNH ĐƯỜNG DẪN GAME (MÀY PHẢI THAY ĐƯỜNG DẪN THẬT VÀO ĐÂY)
    let gameTargetPath = "/var/mobile/Containers/Data/Application/XXXX-XXXX-XXXX-XXXX/Documents/Assembly-CSharp-patch.bytes"
    
    // 1. TAB PROXY
    @State private var proxyFeatures = [
        PatchFeature(name: "Aim Neck", desc: "Aim Cổ Ít Lộ Hơn", icon: "scope", color: .yellow, patchFileName: "AimNeck.3105"),
        PatchFeature(name: "Aim Body", desc: "Aim Ngực / Thân", icon: "figure.stand", color: .orange, patchFileName: "AimBody.3105"),
        PatchFeature(name: "Aimbot", desc: "Tự Động Bắn", icon: "target", color: .red, patchFileName: "Aimbot.3105"),
        PatchFeature(name: "Aim Drag", desc: "Kéo Tâm Lên Đầu", icon: "hand.draw.fill", color: .cyan, patchFileName: "AimDrag.3105"),
        PatchFeature(name: "Aim Magic", desc: "Đạn Ma Thuật", icon: "wand.and.stars", color: .purple, patchFileName: "AimMagic.3105"),
        PatchFeature(name: "Menu", desc: "Menu Hack Trong Game", icon: "gamecontroller.fill", color: .green, patchFileName: "Menu.3105")
    ]
    
    // 2. TAB ĐỊNH VỊ
    @State private var locationFeatures = [
        PatchFeature(name: "Định Vị Súng", desc: "Hiện Vị Trí Súng Trên Map", icon: "location.fill", color: .blue, patchFileName: "Định Vị Súng.3105")
    ]
    
    // 3. TAB MOD NHÂN VẬT
    @State private var modNvFeatures = [
        PatchFeature(name: "Mod Nhân Vật Alock", desc: "Khóa Mục Tiêu Nhân Vật", icon: "person.crop.circle.badge.checkmark", color: .pink, patchFileName: "ModNvAlock.3105")
    ]
    
    var body: some View {
        ZStack {
            // BACKGROUND TÍM ĐEN
            LinearGradient(gradient: Gradient(colors: [Color(red: 0.1, green: 0.05, blue: 0.2), .black]), startPoint: .top, endPoint: .bottom).edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 0) {
                // --- HEADER ---
                HStack {
                    Button(action: {}) {
                        Image(systemName: "chevron.left")
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(.white)
                            .padding(10)
                            .background(Color.white.opacity(0.1))
                            .clipShape(Circle())
                    }
                    Spacer()
                    Text("Free Fire Thường")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundColor(.white)
                    Spacer()
                    Color.clear.frame(width: 40, height: 40)
                }
                .padding(.horizontal, 20)
                .padding(.top, 10)
                
                // --- ICON GAME ---
                Image(systemName: "gamecontroller.fill")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 80, height: 80)
                    .foregroundColor(.orange)
                    .padding(10)
                    .background(Color.white.opacity(0.1))
                    .cornerRadius(20)
                    .padding(.top, 20)
                
                Text("Free Fire Thường")
                    .font(.system(size: 22, weight: .heavy))
                    .foregroundColor(.white)
                    .padding(.top, 10)
                
                Text("com.dts.freefireth")
                    .font(.system(size: 12, design: .monospaced))
                    .foregroundColor(.gray)
                    .padding(.bottom, 20)
                
                // --- TABS ---
                HStack(spacing: 0) {
                    TabButton(title: "Proxy", icon: "bolt.fill", isSelected: selectedTab == 0) { selectedTab = 0 }
                    TabButton(title: "Định Vị", icon: "location.fill", isSelected: selectedTab == 1) { selectedTab = 1 }
                    TabButton(title: "Mod NV", icon: "person.fill", isSelected: selectedTab == 2) { selectedTab = 2 }
                }
                .background(Color.white.opacity(0.05))
                .cornerRadius(15)
                .padding(.horizontal, 20)
                .padding(.bottom, 20)
                
                // --- DANH SÁCH CHỨC NĂNG ---
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 15) {
                        if selectedTab == 0 {
                            ForEach($proxyFeatures) { $feature in
                                FeatureRow(feature: $feature, onToggle: { isOn in
                                    handlePatch(feature: feature, isTurningOn: isOn)
                                })
                            }
                        } else if selectedTab == 1 {
                            ForEach($locationFeatures) { $feature in
                                FeatureRow(feature: $feature, onToggle: { isOn in
                                    handlePatch(feature: feature, isTurningOn: isOn)
                                })
                            }
                        } else if selectedTab == 2 {
                            ForEach($modNvFeatures) { $feature in
                                FeatureRow(feature: $feature, onToggle: { isOn in
                                    handlePatch(feature: feature, isTurningOn: isOn)
                                })
                            }
                        }
                    }
                    .padding(.horizontal, 20)
                }
                
                Spacer()
                
                // --- NÚT MỞ GAME ---
                Button(action: {
                    let url = URL(string: "freefireth://")!
                    if UIApplication.shared.canOpenURL(url) {
                        UIApplication.shared.open(url)
                    }
                }) {
                    HStack {
                        Image(systemName: "play.fill")
                        Text("MỞ GAME")
                            .font(.system(size: 18, weight: .bold))
                    }
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 16)
                    .background(
                        LinearGradient(gradient: Gradient(colors: [Color.purple, Color.cyan]), startPoint: .leading, endPoint: .trailing)
                    )
                    .cornerRadius(15)
                    .shadow(color: .purple.opacity(0.5), radius: 10, x: 0, y: 5)
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 30)
            }
        }
        .preferredColorScheme(.dark)
        .alert(isPresented: $showAlert) {
            Alert(title: Text("Thông báo"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
        }
    }
    
    // --- LOGIC TÌM FILE PATCH TỰ ĐỘNG ---
    func findPatchFile(fileName: String) -> String? {
        guard let bundlePath = Bundle.main.resourcePath else { return nil }
        let fileManager = FileManager.default
        
        if let enumerator = fileManager.enumerator(atPath: bundlePath) {
            for case let path as String in enumerator {
                if path.hasSuffix(fileName) {
                    return "\(bundlePath)/\(path)"
                }
            }
        }
        return nil
    }

    // --- LOGIC GHI ĐÈ VÀ KHÔI PHỤC ---
    func handlePatch(feature: PatchFeature, isTurningOn: Bool) {
        let fileManager = FileManager.default
        
        if isTurningOn {
            if let sourcePath = findPatchFile(fileName: feature.patchFileName) {
                do {
                    if fileManager.fileExists(atPath: gameTargetPath) {
                        try fileManager.removeItem(atPath: gameTargetPath)
                    }
                    try fileManager.copyItem(atPath: sourcePath, toPath: gameTargetPath)
                    alertMessage = "Đã bật \(feature.name)!"
                } catch {
                    alertMessage = "Lỗi bật Patch (Không thể ghi đè): \(error.localizedDescription)"
                    updateFeatureState(feature: feature, isOn: false)
                }
            } else {
                alertMessage = "LỖI: Không tìm thấy file \(feature.patchFileName) trong App!"
                updateFeatureState(feature: feature, isOn: false)
            }
        } else {
            do {
                if fileManager.fileExists(atPath: gameTargetPath) {
                    try fileManager.removeItem(atPath: gameTargetPath)
                    alertMessage = "Đã tắt \(feature.name) và khôi phục file gốc!"
                }
            } catch {
                alertMessage = "Lỗi khôi phục: \(error.localizedDescription)"
            }
        }
        showAlert = true
    }
    
    func updateFeatureState(feature: PatchFeature, isOn: Bool) {
        if let index = proxyFeatures.firstIndex(where: { $0.id == feature.id }) {
            proxyFeatures[index].isOn = isOn
        } else if let index = locationFeatures.firstIndex(where: { $0.id == feature.id }) {
            locationFeatures[index].isOn = isOn
        } else if let index = modNvFeatures.firstIndex(where: { $0.id == feature.id }) {
            modNvFeatures[index].isOn = isOn
        }
    }
}

// --- COMPONENT NÚT TAB ---
struct TabButton: View {
    let title: String
    let icon: String
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack {
                Image(systemName: icon)
                Text(title)
            }
            .font(.system(size: 13, weight: .bold))
            .foregroundColor(isSelected ? .white : .gray)
            .padding(.vertical, 12)
            .frame(maxWidth: .infinity)
            .background(isSelected ? Color.white.opacity(0.1) : Color.clear)
            .cornerRadius(12)
        }
    }
}

// --- COMPONENT DÒNG CHỨC NĂNG ---
struct FeatureRow: View {
    @Binding var feature: PatchFeature
    var onToggle: (Bool) -> Void
    
    var body: some View {
        HStack(spacing: 15) {
            Image(systemName: feature.icon)
                .font(.system(size: 20, weight: .bold))
                .foregroundColor(.white)
                .frame(width: 45, height: 45)
                .background(feature.color)
                .cornerRadius(12)
            
            VStack(alignment: .leading, spacing: 4) {
                Text(feature.name)
                    .font(.system(size: 15, weight: .bold))
                    .foregroundColor(.white)
                Text(feature.desc)
                    .font(.system(size: 11))
                    .foregroundColor(.gray)
            }
            
            Spacer()
            
            Toggle("", isOn: $feature.isOn)
                .labelsHidden()
                .onChange(of: feature.isOn) { newValue in
                    onToggle(newValue)
                }
                .tint(feature.color)
        }
        .padding()
        .background(Color.white.opacity(0.05))
        .cornerRadius(15)
        .overlay(
            RoundedRectangle(cornerRadius: 15)
                .stroke(Color.white.opacity(0.1), lineWidth: 1)
        )
    }
}